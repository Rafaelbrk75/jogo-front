<template>
  <img
    :src="currentSprite"
    alt="Chefão"
    class="boss"
    :style="{ left: bossX + 'px' }"
  />
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from "vue";

// Props:
// - bossX: posição fixa em X (vinda do pai)
// - src1 / src2: caminhos para as duas imagens de animação
const props = defineProps({
  bossX: {
    type: Number,
    default: 1000
  },
  src1: {
    type: String,
    required: true
  },
  src2: {
    type: String,
    required: true
  }
});

const currentSprite = ref(props.src1);
let spriteInterval = null;

onMounted(() => {
  // Troca de sprite a cada 300ms, sem movimentação
  spriteInterval = setInterval(() => {
    currentSprite.value =
      currentSprite.value === props.src1 ? props.src2 : props.src1;
  }, 300);
});

onBeforeUnmount(() => {
  if (spriteInterval) {
    clearInterval(spriteInterval);
    spriteInterval = null;
  }
});
</script>

<style scoped>
.boss {
  position: absolute;
  bottom: 0px;    /* Ajuste a altura conforme necessário */
  width: 350px;   /* Tamanho ajustado */
  transition: left 0.2s;
  z-index: 2;
}
</style>
