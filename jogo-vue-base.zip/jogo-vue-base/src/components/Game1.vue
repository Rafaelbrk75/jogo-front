<!-- Game1.vue -->
<template>
  <GameTemplate
    :cenario="cenario"
    :musica="musica"
    :bossVidaInicial="bossVidaInicial"
    :bossSrc="'/boss.png'" 
  />
</template>

<script setup>
import GameTemplate from './GameTemplate.vue'

const cenario = '/cenario1.png'
const musica = '/nivel1.mp3'
const bossVidaInicial = 3
</script>








