<!-- Game3.vue -->
<template>
  <GameTemplate
    :cenario="cenario"
    :musica="musica"
    :bossVidaInicial="bossVidaInicial"
    :bossSrc="'/bossMoreno.png'"
  />
</template>

<script setup>
import GameTemplate from './GameTemplate.vue'

const cenario = '/cenario3.png'
const musica = '/nivel3.mp3'
const bossVidaInicial = 7
</script>
