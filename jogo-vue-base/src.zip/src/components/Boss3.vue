<template>
  <!-- Usa BossBase apenas para trocar o sprite -->
  <BossBase
  ref="bossBaseRef"
    :initialX="bossX"
    src1="/fase3/boss.png"
    src2="/fase3/boss2.png"
    attackSrc="/fase3/bossatk.png"
    @update:x="onUpdateX"
  />
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref, nextTick } from "vue";
import BossBase from "./BossBase.vue";

const bossX = ref(window.innerWidth - 400);
const bossBaseRef = ref(null);

const emit = defineEmits(["fire-power", "update:x"]);

function onUpdateX(novaX) {
  emit("update:x", novaX);
}

function updateBossPosition() {
  const img = bossBaseRef.value?.bossImg?.value;
  if (img && img.complete) {
    bossX.value = window.innerWidth - img.offsetWidth - 50;
    emit("update:x", bossX.value);
  }
}

let fireInterval = null;

function startFiring() {
  fireInterval = setInterval(() => {
    bossBaseRef.value?.triggerAttack();
    console.log("🔥 emitindo poder em x =", bossX.value);

    emit("fire-power", {
      sprite: "/fase3/poder-binario.png",
      speed: 7,
      x: bossX.value,
      y: 300 // ajuste se necessário
    });
  }, 2000);
}

// 👇 Função nomeada para facilitar remoção posterior
function handleImgLoad() {
  updateBossPosition();
  startFiring();
}


onMounted(async () => {
  await nextTick();
  const img = bossBaseRef.value?.bossImg?.value;

  if (img) {
    img.addEventListener("load", handleImgLoad);

    // Mesmo que a imagem já esteja carregada, garantimos a chamada
    if (img.complete) {
      handleImgLoad();
    }
  }

  window.addEventListener("resize", updateBossPosition);
});



onBeforeUnmount(() => {
  window.removeEventListener("resize", updateBossPosition);
  const img = bossBaseRef.value?.bossImg?.value;
  if (img) img.removeEventListener("load", handleImgLoad);
  if (fireInterval) clearInterval(fireInterval);
});
</script>



