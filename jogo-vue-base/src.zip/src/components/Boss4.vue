<template>
  <BossBase
    ref="bossBaseRef"
    :initialX="bossX"
    :initialY="bossY"
    src1="/fase4/boss.png"
    src2="/fase4/boss2.png"
    attackSrc="/fase4/bossatk.png"
    @update:x="onUpdateX"
    :style="{ position: 'absolute', top: bossY + 'px', left: bossX + 'px' }"
  />
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref, nextTick } from "vue";
import BossBase from "./BossBase.vue";

const emit = defineEmits(["fire-power", "update:x", "update:y"]);

const bossX = ref(window.innerWidth - 400);
const bossY = ref(300);
const bossBaseRef = ref(null);

let fireInterval = null;
let teleportInterval = null;

function onUpdateX(novaX) {
  emit("update:x", novaX);
}

function updateBossPosition() {
  const img = bossBaseRef.value?.getBossImg?.()?.value;
  if (img && img.complete) {
    bossX.value = window.innerWidth - img.offsetWidth - 50;
    emit("update:x", bossX.value);
  }
}

function handleImgLoad() {
  console.log("📦 Boss4 imagem carregada!");
  updateBossPosition();
  startFiring();
  startTeleporting();
}

function startFiring() {
  let contador = 0;
  if (fireInterval) clearInterval(fireInterval);

  fireInterval = setInterval(() => {
    bossBaseRef.value?.triggerAttack();
    console.log("🔥 Disparo Boss 4 em x =", bossX.value);

    contador++;

    const frames = [
      "/fase4/poderhugo1.png",
      "/fase4/poderhugo2.png",
      "/fase4/poderhugo3.png",
      "/fase4/poderhugo4.png"
    ]

    const basePayload = { frames, x: bossX.value, y: bossY.value };

    if (contador % 8 === 0) {
      emit("fire-power", { ...basePayload, speed: 10 });
      emit("fire-power", { ...basePayload, speed: 7 });
      emit("fire-power", { ...basePayload, speed: 12 });
    } else {
      emit("fire-power", { ...basePayload, speed: 9 });
    }
  }, 1200);
}

function startTeleporting() {
  console.log("🌀 Boss4 começou a teleportar!");
  const larguraBoss = 350;
  const alturaBoss = 350;
  const margem = 100;

  const somTeleporte = new Audio("/fase4/teleport.mp3");
  somTeleporte.volume = 1.0;

  teleportInterval = setInterval(() => {
    const novaX = Math.max(50, Math.min(window.innerWidth - larguraBoss - margem, Math.random() * window.innerWidth));
    const novaY = Math.max(100, Math.min(window.innerHeight - alturaBoss - 200, Math.random() * window.innerHeight));

    const img = bossBaseRef.value?.bossImg?.value || bossBaseRef.value?.getBossImg?.().value;
    if (img) {
      img.style.opacity = 0;
      setTimeout(() => {
        bossX.value = novaX;
        bossY.value = novaY;
        emit("update:x", bossX.value);
        emit("update:y", bossY.value);
        img.style.opacity = 1;
      }, 300);
    } else {
      bossX.value = novaX;
      bossY.value = novaY;
      emit("update:x", bossX.value);
      emit("update:y", bossY.value);
    }

    somTeleporte.currentTime = 0;
    somTeleporte.play().catch(() => {});
    console.log("🌀 Teleportando boss para:", novaX, novaY);
  }, 3000);
}

onMounted(async () => {
  await nextTick();

  setTimeout(() => {
  const imgRef = bossBaseRef.value?.getBossImg?.();
  const img = imgRef?.value;

  if (img) {
    console.log("✅ Imagem do boss encontrada:", img);
    if (img.complete) {
      handleImgLoad();
    } else {
      img.addEventListener("load", handleImgLoad);
    }
  }
}, 100);

});

onBeforeUnmount(() => {
  window.removeEventListener("resize", updateBossPosition);
  const img = bossBaseRef.value?.bossImg?.value || bossBaseRef.value?.getBossImg?.().value;
  if (img) img.removeEventListener("load", handleImgLoad);
  clearInterval(fireInterval);
  clearInterval(teleportInterval);
});

</script>

<style scoped>
.boss.boss4 {
  position: absolute !important;
}
</style>
