<template>
  <BossBase ref="bossBaseRef" :initialX="bossX" src1="/fase4/boss.png" src2="/fase4/boss2.png"
    attackSrc="/fase4/bossatk.png" @update:x="onUpdateX"
    :style="{ top: bossY + 'px', left: bossX + 'px', position: 'absolute' }" />
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref, nextTick } from "vue";
import BossBase from "./BossBase.vue";

const bossX = ref(window.innerWidth - 400);
const bossY = ref(300);
const bossBaseRef = ref(null);
const emit = defineEmits(["fire-power", "update:x", "update:y"]);

let fireInterval = null;
let teleportInterval = null;

// Atualiza posição X recebida do BossBase
function onUpdateX(novaX) {
  emit("update:x", novaX);
}

function updateBossPosition() {
  const img = bossBaseRef.value?.bossImg?.value;
  if (img && img.complete) {
    bossX.value = window.innerWidth - img.offsetWidth - 50;
    emit("update:x", bossX.value);
  }
}

function handleImgLoad() {
  console.log("📦 Boss4 imagem carregada!");
  updateBossPosition();
  startFiring();
  startTeleporting();
}

function startFiring() {
  let contador = 0;
  if (fireInterval) clearInterval(fireInterval);

  fireInterval = setInterval(() => {
    bossBaseRef.value?.triggerAttack();
    console.log("🔥 Disparo Boss 4 em x =", bossX.value);

    contador++;
    if (contador % 3 === 0) {
      emit("fire-power", { frames: ["/fase4/poder-binario.png"], speed: 10, x: bossX.value, y: bossY.value });
      emit("fire-power", { frames: ["/fase4/poder-binario.png"], speed: 7, x: bossX.value, y: bossY.value });
      emit("fire-power", { frames: ["/fase4/poder-binario.png"], speed: 12, x: bossX.value, y: bossY.value });
    } else {
      emit("fire-power", { frames: ["/fase4/poder-binario.png"], speed: 9, x: bossX.value, y: bossY.value });
    }
  }, 1200);
}



function startTeleporting() {
  console.log("🌀 Boss4 começou a teleportar!");
  const larguraBoss = 350;
  const alturaBoss = 350;
  const margem = 100;

  const somTeleporte = new Audio("/fase4/teleport.mp3");
  somTeleporte.volume = 1.0;

  teleportInterval = setInterval(() => {
    const novaX = Math.max(50, Math.min(window.innerWidth - larguraBoss - margem, Math.random() * window.innerWidth));
    const novaY = Math.max(100, Math.min(window.innerHeight - alturaBoss - 200, Math.random() * window.innerHeight));

    const img = bossBaseRef.value?.bossImg?.value;
    if (img) {
      img.style.opacity = 0;
      setTimeout(() => {
        bossX.value = novaX;
        bossY.value = novaY;
        emit("update:x", bossX.value);
        emit("update:y", bossY.value); // ✅ necessário para GameTemplate
        img.style.opacity = 1;
      }, 300);
    } else {
      bossX.value = novaX;
      bossY.value = novaY;
      emit("update:x", bossX.value);
      emit("update:y", bossY.value);
    }

    somTeleporte.currentTime = 0;
    somTeleporte.play().catch(() => { });
    console.log("🌀 Teleportando boss para:", novaX, novaY);
  }, 3000);
}

onMounted(async () => {
  await nextTick();

  setTimeout(() => {
    const img = bossBaseRef.value?.bossImg?.value;
    if (img) {
      img.addEventListener("load", handleImgLoad);
      if (img.complete) {
        handleImgLoad();
      }
    } else {
      console.warn("❌ Imagem do boss não encontrada!");
    }
  }, 100); // Pequeno delay para garantir render
});


onBeforeUnmount(() => {
  window.removeEventListener("resize", updateBossPosition);
  const img = bossBaseRef.value?.bossImg?.value;
  if (img) img.removeEventListener("load", handleImgLoad);
  if (fireInterval) clearInterval(fireInterval);
  if (teleportInterval) clearInterval(teleportInterval);
});
</script>

<style scoped>
.boss.boss4 {
  position: absolute !important;
}
</style>
