<template>
  <div>
    <!-- Tela de Menu -->
    <Menu v-if="telaAtual === 'menu'" @start="exibirIntro" />

    <!-- HQ de Introdução -->
    <div v-else-if="telaAtual === 'intro'" class="intro-hq">
      <img src="/fase1/hq-intro.png" class="hq-img" alt="HQ Intro" />
      <button class="btn-skip" @click="pularIntro">PULAR</button>
    </div>

    <!-- Tela de Jogo -->
    <div
      v-else-if="telaAtual === 'jogo'"
      class="cenario"
      :style="{ backgroundImage: `url('${cenario}')` }"
    >
      <Hud :vidas="vidas" />

      <!-- Sombra do Boss -->
      <img src="/sombra.png" class="sombra sombra-boss" />

      <!-- Barra de vida do Boss -->
      <div class="barra-vida">
        <div
          class="barra-vida-fill"
          :style="{ width: (bossVida / bossVidaInicial) * 100 + '%' }"
        ></div>
      </div>

      <!-- Aqui carregamos o boss correto, de acordo com faseAtual -->
      <component
        :is="bossComponent"
        :initialX="bossX"
        @update:x="bossX = $event"
        @fire-power="startBossPower"
        @tocarPlayer="levarDano"
      />

      <!-- Sombra do Player -->
      <img
        src="/sombra.png"
        class="sombra sombra-player"
        :style="{ left: playerX + 45 + 'px', bottom: '-50px' }"
      />

      <!-- Moedas -->
      <img
        v-if="mostrarMoeda"
        :src="moedas.bronze[moedaFrame - 1]"
        alt="Moeda Girando"
        class="moeda-girando"
      />
      <img
        v-if="mostrarMoedaPrata"
        :src="moedas.prata[moedaPrataFrame - 1]"
        alt="Moeda Prata Girando"
        class="moeda-girando"
      />
      <img
        v-if="mostrarMoedaDourada"
        :src="moedas.dourada[moedaDouradaFrame - 1]"
        class="moeda-girando-dourada"
      />

      <!-- Perguntas -->
      <div v-if="mostrarPergunta" class="pergunta-overlay" @click.stop>
        <img :src="perguntaBronze.imagem" class="img-pergunta" />
        <div class="contador">{{ tempoRestAnte }}</div>
      </div>
      <div v-if="mostrarPerguntaPrata" class="pergunta-overlay" @click.stop>
        <img :src="perguntaPrata.imagem" class="img-pergunta" />
        <div class="contador">{{ tempoRestAnte }}</div>
      </div>
      <div v-if="mostrarPerguntaDourada" class="pergunta-overlay" @click.stop>
        <img :src="perguntaDourada.imagem" class="img-pergunta" />
        <div class="contador">{{ tempoRestAnte }}</div>
      </div>

      <!-- Player (envia posição/estado via eventos emitidos) -->
      <Player
        :initialX="playerX"
        :initialY="jumpY"
        :pausado="jogoPausado || perguntaPausandoJogo"
        @update:x="playerX = $event"
        @update:y="jumpY = $event"
        @update:direcao="direcao = $event"
        @update:estado="onPlayerEstado($event)"
      />

      <!-- Poder (vindo do Boss) -->
      <img
        v-if="poderVisivel"
        ref="poder"
        :src="poderSprite"
        alt="Poder"
        class="poder"
        :style="{ right: poderX + 'px' }"
      />

      <!-- Renderiza todos os poderes ativos do boss -->
      <img
        v-for="(poder, idx) in poderes"
        :key="idx"
        :src="poder.sprite"
        class="poder"
        :style="{ left: poder.x + 'px', bottom: (poder.y || 160) + 'px' }"
      />

      <!-- Tiro de Laser do Player -->
      <img
        v-if="tiroVisivel"
        src="/impacto_laser_pixelado.png"
        alt="Tiro de Laser"
        class="tiro"
        :style="{ left: tiroX + 'px', bottom: tiroY + 'px' }"
      />

      <!-- Áudios -->
      <audio ref="somNivel1" :src="musica" loop />
      <audio ref="somImpacto" src="/somImpacto.mp3" />
      <audio ref="somGameOver" src="/gameover.mp3" />
      <audio ref="somAgachando" src="/somAgachando.mp3" />
      <audio ref="somPulo" src="/somPulo.mp3" />
      <audio ref="somMoeda" src="/public/somMoeda.wav" />
      <audio ref="somAcerto" src="/somAcerto.wav" />
      <audio ref="somPerda" src="/somPerda.mp3" />
      <audio ref="somRelogio" src="/somRelogio.mp3" />

      <!-- Botão de Som -->
      <button @click.stop="toggleSom" class="btn-som">
        <img
          :src="somAtivo ? '/iconSomLigado.png' : '/iconSomDesligado.png'"
          alt="Som"
        />
      </button>

      <!-- Overlay de Pause -->
      <div v-if="jogoPausado" class="pause-overlay">
        <img src="/telaPause.png" class="img-pause" alt="Pausado" />
        <button
          v-if="jogoPausado"
          class="btn-continuar"
          @click.stop="togglePause"
        >
          CONTINUAR
        </button>
      </div>

      <!-- Tela de Game Over -->
      <div v-if="gameOver" class="game-over-overlay">
        <div class="game-over-container">
          <img src="/imgGameOver.png" class="img-game-over" alt="Game Over" />
          <button class="btn-reiniciar" @click="reiniciarJogo">
            REINICIAR
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import {
  ref,
  reactive,
  computed,
  watch,
  onBeforeUnmount,
  onMounted,
} from "vue";
import Menu from "./Menu.vue";
import Hud from "./Hud.vue";
import Player from "./Player.vue";

// Importamos as fases de Boss
import BossFase1 from "./Boss1.vue";
import BossFase2 from "./Boss2.vue";

const props = defineProps({
  exibirMenu: { type: Boolean, default: false }, // ← ADICIONADO
  cenario: { type: String, required: true },
  musica: { type: String, required: true },
  bossVidaInicial: { type: Number, default: 3 },
  bossComponent: { type: Object, required: true },
  perguntas: { type: Object, required: true },
  moedas: { type: Object, required: true },
});


// ──────────────────────────────────────────────────────────────
// Estados principais do GameTemplate
// ──────────────────────────────────────────────────────────────
const telaAtual = ref(props.exibirMenu ? "menu" : "jogo");
let introTimeoutId = null;

const vidas = reactive([true, true, true]);
const playerX = ref(50);
function atualizarX(novoX) {
  playerX.value = novoX;
}
const jumpY = ref(0);
const direcao = ref("direita");

// Essas duas refs são atualizadas pelo evento @update:estado do Player
const estaAgachado = ref(false);
const groundedGlob = ref(true);

// Variável que controla em que fase estamos (1 ou 2 neste exemplo)
const faseAtual = ref(1);

// Computed para eleger o boss correspondente a cada fase
const componenteBoss = computed(() => {
  return faseAtual.value === 1 ? BossFase1 : BossFase2;
});

// posição X do boss (recebida dos eventos @update:x)
const bossX = ref(window.innerWidth - 400); // exemplo de valor inicial razoável

// Tudo relativo ao “poder” do boss
const poderX = ref(0);
const poderVisivel = ref(false);
const invulneravel = ref(false);

// Qual sprite de poder exibir (muda conforme evento “fire-power”)
const poderSprite = ref("/poderFase1.png");

// Áudios e som
const somNivel1 = ref(null);
const somImpacto = ref(null);
const somGameOver = ref(null);
const somAgachando = ref(null);
const somPulo = ref(null);
const somMoeda = ref(null);
const somAcerto = ref(null);
const somPerda = ref(null);
const somRelogio = ref(null);
const somAtivo = ref(false);

const jogoPausado = ref(false);
const gameOver = ref(false);

const moedaFrame = ref(1);
const mostrarMoeda = ref(false);
const moedaPrataFrame = ref(1);
const mostrarMoedaPrata = ref(false);
const moedaDouradaFrame = ref(1);
const mostrarMoedaDourada = ref(false);

const mostrarPergunta = ref(false);
const mostrarPerguntaPrata = ref(false);
const mostrarPerguntaDourada = ref(false);
const respostaDigitada = ref("");
const tempoRestAnte = ref(10);
const perguntaPausandoJogo = ref(false);

const bossVida = ref(props.bossVidaInicial);

const perguntaBronze = computed(() => props.perguntas.bronze);
const perguntaPrata = computed(() => props.perguntas.prata);
const perguntaDourada = computed(() => props.perguntas.dourada);

const tiroVisivel = ref(false);
const tiroX = ref(0);
const tiroY = ref(0);
const tiroSpeed = 30;
let tiroAnimFrame = null;

let frameLoop = null;
let moedaAnimacao = null;
let animacaoPrata = null;
let animacaoDourada = null;
let timerPergunta = null;

const poderes = reactive([]);

// ──────────────────────────────────────────────────────────────
// Exibe a HQ antes de iniciar o jogo
// ──────────────────────────────────────────────────────────────
function exibirIntro() {
  telaAtual.value = "intro";
  clearTimeout(introTimeoutId);
  introTimeoutId = setTimeout(() => {
    if (telaAtual.value === "intro") iniciarJogo();
  }, 8000);
}

// Pula a HQ e inicia imediatamente
function pularIntro() {
  clearTimeout(introTimeoutId);
  iniciarJogo();
}

// ──────────────────────────────────────────────────────────────
// Inicia o jogo (setting up loops, sons, etc.)
// ──────────────────────────────────────────────────────────────
function iniciarJogo() {
  telaAtual.value = "jogo";

  // Tocar música de fundo
  if (somNivel1.value) {
    somNivel1.value.currentTime = 0;
    somNivel1.value.loop = true;
    somNivel1.value.play().catch(() => {});
  }
  somAtivo.value = true;
  gameOver.value = false;

  // Resetar tudo
  vidas.splice(0, vidas.length, true, true, true);
  poderes.splice(0, poderes.length); // limpa todos os poderes
  poderVisivel.value = false;
  playerX.value = 50;
  jumpY.value = 0;
  bossX.value = 1475;
  poderX.value = 0;
  poderVisivel.value = false;
  moedaFrame.value = 1;
  moedaPrataFrame.value = 1;
  moedaDouradaFrame.value = 1;
  mostrarMoeda.value = false;
  mostrarMoedaPrata.value = false;
  mostrarMoedaDourada.value = false;
  mostrarPergunta.value = false;
  mostrarPerguntaPrata.value = false;
  mostrarPerguntaDourada.value = false;
  respostaDigitada.value = "";
  tempoRestAnte.value = 10;
  estaAgachado.value = false;
  groundedGlob.value = true;

  bossVida.value = props.bossVidaInicial;

  // Inicia loop de jogo (colisões e perguntas)
  frameLoop = requestAnimationFrame(gameLoop);

  // Mostrar moeda bronze após 7s
  setTimeout(() => {
    mostrarMoeda.value = true;
    moedaAnimacao = setInterval(() => {
      moedaFrame.value = moedaFrame.value === 4 ? 1 : moedaFrame.value + 1;
    }, 150);
  }, 7000);
}

// ──────────────────────────────────────────────────────────────
// Quando o BossFaseX emitir “fire-power” com { sprite, speed }
// chamamos esta função para animar o “poder” no canvas
// ──────────────────────────────────────────────────────────────

function startBossPower({ sprite, speed, x, y }) {
  console.log("Recebido fire-power:", sprite, speed, x, y);
  if (gameOver.value) return;
  poderes.push({
    sprite,
    x: x ?? bossX.value,
    y: y ?? 100,
    speed,
  });
}

// ──────────────────────────────────────────────────────────────
// Tratamento de teclas para o jogo (pausar, respostas, tiro)
// ──────────────────────────────────────────────────────────────

function onKeyDown(e) {
  if (e.key === "Escape") {

    togglePause();
    return;
  }

  if (jogoPausado.value || gameOver.value) return;

  // Responder pergunta bronze
  if (mostrarPergunta.value && /^[a-zA-Z-Z0-9]$/.test(e.key)) {
    const tecla = e.key.toUpperCase();
    if (tecla === perguntaBronze.value.resposta.toUpperCase()) {
      encerrarPergunta(true);
    } else {
      encerrarPergunta(false);
    }
  }

  // Responder pergunta prata
  if (mostrarPerguntaPrata.value && /^[a-zA-Z0-9]$/.test(e.key)) {
    const tecla = e.key.toString().toUpperCase();
    if (tecla === perguntaPrata.value.resposta.toString().toUpperCase()) {
      encerrarPerguntaPrata(true);
    } else {
      encerrarPerguntaPrata(false);
    }
  }

  // Responder pergunta dourada
  if (mostrarPerguntaDourada.value && /^[a-zA-Z0-9]$/.test(e.key)) {
    const tecla = e.key.toString().toUpperCase();
    if (tecla === perguntaDourada.value.resposta.toString().toUpperCase()) {
      encerrarPerguntaDourada(true);
    } else {
      encerrarPerguntaDourada(false);
    }
  }

  // Pular HQ no menu
  if (e.key === "Enter" && telaAtual.value === "menu") {
    exibirIntro();
  }

  // Disparar tiro
  if (e.key.toLowerCase() === "f") {
    dispararTiro();
  }
}

function onKeyUp(_) {
  // nada aqui
}

// ──────────────────────────────────────────────────────────────
// Função que dispara o laser (tiro do player)
// ──────────────────────────────────────────────────────────────
function dispararTiro() {
  if (tiroVisivel.value) return;
  tiroX.value = playerX.value + 60;
  tiroY.value = jumpY.value + 40;
  tiroVisivel.value = true;

  function animarTiro() {
    if (jogoPausado.value || gameOver.value) {
      cancelAnimationFrame(tiroAnimFrame);
      return;
    }
    tiroX.value += tiroSpeed;

    const bossEl = document.querySelector(".boss");
    const tiroEl = document.querySelector(".tiro");
    if (bossEl && tiroEl) {
      const rBoss = bossEl.getBoundingClientRect();
      const rTiro = tiroEl.getBoundingClientRect();
      const houveColisao =
        rTiro.left < rBoss.right &&
        rTiro.right > rBoss.left &&
        rTiro.top < rBoss.bottom &&
        rTiro.bottom > rBoss.top;

      if (houveColisao) {
        if (bossVida.value > 0) {
          bossVida.value--;
        }
        tiroVisivel.value = false;
        cancelAnimationFrame(tiroAnimFrame);
        if (bossVida.value <= 0) {
          emitirVitoria();
        }
        return;
      }
    }

    if (tiroX.value > window.innerWidth + 180) {
      tiroVisivel.value = false;
      cancelAnimationFrame(tiroAnimFrame);
      return;
    }
    tiroAnimFrame = requestAnimationFrame(animarTiro);
  }
  tiroAnimFrame = requestAnimationFrame(animarTiro);
}

// ──────────────────────────────────────────────────────────────
// Loop principal do jogo (colisões com moedas e trigger de perguntas)
// ──────────────────────────────────────────────────────────────
function gameLoop() {
  if (jogoPausado.value || perguntaPausandoJogo.value || gameOver.value) return;

  // Colisão com moeda bronze
  const checarColisaoMoeda = (selector, onCollect) => {
    const moedaEl = document.querySelector(selector);
    const playerEl = document.querySelector(".player");
    if (moedaEl && playerEl) {
      const r1 = moedaEl.getBoundingClientRect();
      const r2 = playerEl.getBoundingClientRect();
      const colidiu =
        r1.left < r2.right &&
        r1.right > r2.left &&
        r1.top < r2.bottom &&
        r1.bottom > r2.top;
      if (colidiu) onCollect();
    }
  };

  if (mostrarMoeda.value) {
    checarColisaoMoeda(".moeda-girando", () => {
      mostrarMoeda.value = false;
      if (somMoeda.value && somAtivo.value) {
        somMoeda.value.currentTime = 0;
        somMoeda.value.play().catch(() => {});
      }
      iniciarPergunta();
    });
  }
  if (mostrarMoedaPrata.value) {
    checarColisaoMoeda(".moeda-girando", () => {
      mostrarMoedaPrata.value = false;
      if (somMoeda.value && somAtivo.value) {
        somMoeda.value.currentTime = 0;
        somMoeda.value.play().catch(() => {});
      }
      iniciarPerguntaPrata();
    });
  }
  if (mostrarMoedaDourada.value) {
    checarColisaoMoeda(".moeda-girando-dourada", () => {
      mostrarMoedaDourada.value = false;
      if (somMoeda.value && somAtivo.value) {
        somMoeda.value.currentTime = 0;
        somMoeda.value.play().catch(() => {});
      }
      iniciarPerguntaDourada();
    });
  }

  // Atualiza e remove poderes do boss
  for (let i = poderes.length - 1; i >= 0; i--) {
    console.log("Poder", i, poderes[i]);
    poderes[i].x -= poderes[i].speed;

    const playerEl = document.querySelector(".player");
    const poderEls = document.querySelectorAll(".poder");
    const poderEl = poderEls[i];
    if (playerEl && poderEl) {
      const rPlayer = playerEl.getBoundingClientRect();
      const rPoder = poderEl.getBoundingClientRect();

      const colidiu =
        rPoder.left < rPlayer.right &&
        rPoder.right > rPlayer.left &&
        rPoder.top < rPlayer.bottom &&
        rPoder.bottom > rPlayer.top;

      if (colidiu) {
        // Remove uma vida
        const idx = vidas.findIndex((v) => v);
        if (idx !== -1) vidas[idx] = false;
        poderes.splice(i, 1);
        verificarGameOver();
        continue;
      }
    }

    if (poderes[i] && poderes[i].x < -200) {
      poderes.splice(i, 1);
    }
  }

  frameLoop = requestAnimationFrame(gameLoop);
}

// ──────────────────────────────────────────────────────────────
// Pergunta Bronze
// ──────────────────────────────────────────────────────────────
function iniciarPergunta() {
  mostrarPergunta.value = true;
  respostaDigitada.value = "";
  tempoRestAnte.value = 10;
  perguntaPausandoJogo.value = true;
  if (somRelogio.value && somAtivo.value) {
    somRelogio.value.currentTime = 0;
    somRelogio.value.play().catch(() => {});
  }

  timerPergunta = setInterval(() => {
    tempoRestAnte.value--;
    if (tempoRestAnte.value <= 0) {
      encerrarPergunta(false);
    }
  }, 1000);
}

function encerrarPergunta(acertou) {
  if (!mostrarPergunta.value) return;
  clearInterval(timerPergunta);
  mostrarPergunta.value = false;
  perguntaPausandoJogo.value = false;
  if (somRelogio.value) somRelogio.value.pause();

  if (somAtivo.value) {
    if (acertou && somAcerto.value) {
      somAcerto.value.currentTime = 0;
      somAcerto.value.play().catch(() => {});
    } else if (!acertou && somPerda.value) {
      somPerda.value.currentTime = 0;
      somPerda.value.play().catch(() => {});
      const idx = vidas.findIndex((v) => v);
      if (idx !== -1) vidas[idx] = false;
      verificarGameOver();
    }
  }

  frameLoop = requestAnimationFrame(gameLoop);

  // Após 2s, aparece moeda prata
  setTimeout(() => {
    mostrarMoedaPrata.value = true;
    moedaPrataFrame.value = 1;
    animacaoPrata = setInterval(() => {
      moedaPrataFrame.value =
        moedaPrataFrame.value === 4 ? 1 : moedaPrataFrame.value + 1;
    }, 150);
  }, 2000);
}

// ──────────────────────────────────────────────────────────────
// Pergunta Prata
// ──────────────────────────────────────────────────────────────
function iniciarPerguntaPrata() {
  mostrarPerguntaPrata.value = true;
  respostaDigitada.value = "";
  tempoRestAnte.value = 10;
  perguntaPausandoJogo.value = true;
  if (somRelogio.value && somAtivo.value) {
    somRelogio.value.currentTime = 0;
    somRelogio.value.play().catch(() => {});
  }

  timerPergunta = setInterval(() => {
    tempoRestAnte.value--;
    if (tempoRestAnte.value <= 0) {
      encerrarPerguntaPrata(false);
    }
  }, 1000);
}

function encerrarPerguntaPrata(acertou) {
  if (!mostrarPerguntaPrata.value) return;
  clearInterval(timerPergunta);
  mostrarPerguntaPrata.value = false;
  perguntaPausandoJogo.value = false;
  if (somRelogio.value) somRelogio.value.pause();

  if (somAtivo.value) {
    if (acertou && somAcerto.value) {
      somAcerto.value.currentTime = 0;
      somAcerto.value.play().catch(() => {});
    } else if (!acertou && somPerda.value) {
      somPerda.value.currentTime = 0;
      somPerda.value.play().catch(() => {});
      const idx = vidas.findIndex((v) => v);
      if (idx !== -1) vidas[idx] = false;
      verificarGameOver();
    }
  }

  frameLoop = requestAnimationFrame(gameLoop);

  // Após 4s, aparece moeda dourada
  setTimeout(() => {
    mostrarMoedaDourada.value = true;
    moedaDouradaFrame.value = 1;
    animacaoDourada = setInterval(() => {
      moedaDouradaFrame.value =
        moedaDouradaFrame.value === 4 ? 1 : moedaDouradaFrame.value + 1;
    }, 150);
  }, 4000);
}

// ──────────────────────────────────────────────────────────────
// Pergunta Dourada
// ──────────────────────────────────────────────────────────────
function iniciarPerguntaDourada() {
  mostrarPerguntaDourada.value = true;
  respostaDigitada.value = "";
  tempoRestAnte.value = 10;
  perguntaPausandoJogo.value = true;
  if (somRelogio.value && somAtivo.value) {
    somRelogio.value.currentTime = 0;
    somRelogio.value.play().catch(() => {});
  }

  timerPergunta = setInterval(() => {
    tempoRestAnte.value--;
    if (tempoRestAnte.value <= 0) {
      encerrarPerguntaDourada(false);
    }
  }, 1000);
}

function encerrarPerguntaDourada(acertou) {
  if (!mostrarPerguntaDourada.value) return;
  clearInterval(timerPergunta);
  mostrarPerguntaDourada.value = false;
  perguntaPausandoJogo.value = false;
  if (somRelogio.value) somRelogio.value.pause();

  if (somAtivo.value) {
    if (acertou && somAcerto.value) {
      somAcerto.value.currentTime = 0;
      somAcerto.value.play().catch(() => {});
    } else if (!acertou && somPerda.value) {
      somPerda.value.currentTime = 0;
      somPerda.value.play().catch(() => {});
      let perdidas = 0;
      for (let i = 0; i < vidas.length && perdidas < 3; i++) {
        if (vidas[i]) {
          vidas[i] = false;
          perdidas++;
        }
      }
      verificarGameOver();
    }
  }

  frameLoop = requestAnimationFrame(gameLoop);
}

// ──────────────────────────────────────────────────────────────
// Verifica Game Over
// ──────────────────────────────────────────────────────────────
function verificarGameOver() {
  if (vidas.every((v) => !v)) {
    gameOver.value = true;
    limparJogo();
    if (somNivel1.value) somNivel1.value.pause();
    if (somGameOver.value && somAtivo.value) {
      somGameOver.value.currentTime = 0;
      somGameOver.value.play().catch(() => {});
    }
  }
}

// ──────────────────────────────────────────────────────────────
// Emitir Vitória de Fase
// ──────────────────────────────────────────────────────────────
const emit = defineEmits(["vencerNivel"]);
function emitirVitoria() {
  emit("vencerNivel");
  // Ao vencer a fase, você pode incrementar `faseAtual.value++` para mudar o boss:
  faseAtual.value++;
}

// ──────────────────────────────────────────────────────────────
// Reiniciar Jogo
// ──────────────────────────────────────────────────────────────
function reiniciarJogo() {
  vidas.splice(0, vidas.length, true, true, true);
  poderes.splice(0, poderes.length);
  poderVisivel.value = false;
  mostrarMoeda.value = false;
  mostrarMoedaPrata.value = false;
  mostrarMoedaDourada.value = false;
  mostrarPergunta.value = false;
  mostrarPerguntaPrata.value = false;
  mostrarPerguntaDourada.value = false;
  respostaDigitada.value = "";
  tempoRestAnte.value = 10;
  playerX.value = 50;
  jumpY.value = 0;
  gameOver.value = false;

  // Corrigido: não retornar para a tela de menu
  telaAtual.value = "jogo";
}


// ──────────────────────────────────────────────────────────────
// Limpar estados ao desmontar / mudar fase
// ──────────────────────────────────────────────────────────────
function limparJogo() {
  window.removeEventListener("keydown", onKeyDown);
  window.removeEventListener("keyup", onKeyUp);
  if (frameLoop) cancelAnimationFrame(frameLoop);
  if (timerPergunta) clearInterval(timerPergunta);
  if (moedaAnimacao) clearInterval(moedaAnimacao);
  if (animacaoPrata) clearInterval(animacaoPrata);
  if (animacaoDourada) clearInterval(animacaoDourada);
  if (somNivel1.value) somNivel1.value.pause();
  if (tiroAnimFrame) cancelAnimationFrame(tiroAnimFrame);
}

// ──────────────────────────────────────────────────────────────
// Liga/Desliga Som
// ──────────────────────────────────────────────────────────────
function toggleSom() {
  if (!somNivel1.value) return;
  somAtivo.value = !somAtivo.value;
  if (somAtivo.value) somNivel1.value.play().catch(() => {});
  else somNivel1.value.pause();
}

// ──────────────────────────────────────────────────────────────
// Liga/Desliga Pause
// ──────────────────────────────────────────────────────────────
function togglePause() {
  jogoPausado.value = !jogoPausado.value;
  if (jogoPausado.value) {
    if (somNivel1.value) somNivel1.value.pause();
    if (timerPergunta) clearInterval(timerPergunta);
    if (frameLoop) cancelAnimationFrame(frameLoop); // Impedir o jogo ficar funcionando quando estiver pausado
  } else {
    if (somAtivo.value && somNivel1.value)
      somNivel1.value.play().catch(() => {});
    if (!perguntaPausandoJogo.value)
      frameLoop = requestAnimationFrame(gameLoop);
  }
}

// ──────────────────────────────────────────────────────────────
// Controla troca de tela e listener de teclado
// ──────────────────────────────────────────────────────────────
watch(telaAtual, (t) => {
  if (t === "jogo") {
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    iniciarJogo();
  } else {
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    limparJogo();
  }
});

onBeforeUnmount(() => limparJogo());

onMounted(() => {
  const tentarTocarSom = () => {
    if (telaAtual.value === "jogo" && somNivel1.value && somAtivo.value) {
      somNivel1.value.play().catch(() => {});
    }
    window.removeEventListener("click", tentarTocarSom);
  };
  window.addEventListener("click", tentarTocarSom);
  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
});

// Quando o Player.vue emite estado de “grounded” e “agachado”:
function onPlayerEstado(payload) {
  groundedGlob.value = payload.grounded;
  estaAgachado.value = payload.agachado;
}

function levarDano() {
  if (invulneravel.value || jogoPausado.value) return;

  const idx = vidas.findIndex((v) => v);
  if (idx !== -1) vidas[idx] = false;

  verificarGameOver();

  invulneravel.value = true;
  setTimeout(() => {
    invulneravel.value = false;
  }, 2000);
}
</script>

<style scoped>
@import url("https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap");

.cenario {
  position: relative;
  width: 100vw;
  height: 100vh;
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center center;
  image-rendering: pixelated;
  overflow: hidden;
}

.sombra {
  width: 150px;
  height: auto;
  image-rendering: pixelated;
  pointer-events: none;
  opacity: 0.4;
  filter: brightness(0.2);
  z-index: 1;
  bottom: -50px;
}

.sombra-player {
  position: absolute;
  bottom: -60px;
  z-index: 1;
  transition: left 0.1s;
}

.sombra-boss {
  position: absolute;
  bottom: -134px;
  right: 70px;
  width: 320px;
  height: auto;
  image-rendering: pixelated;
  pointer-events: none;
  opacity: 0.2;
  filter: brightness(0.2);
  z-index: 1;
}

.poder {
  position: absolute;
  bottom: 160px;
  height: 80px; /* ajuste conforme tamanho do sprite do poder */
  transition: right 0.05s;
  z-index: 2;
  image-rendering: pixelated;
}

.btn-som {
  position: absolute;
  top: 10px;
  right: 20px;
  background: none;
  border: none;
  cursor: pointer;
  z-index: 20;
  padding: 3em;
}

.btn-som img {
  width: 60px;
  height: 60px;
}

.game-over-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.9);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.game-over-container {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}

.img-game-over {
  width: 100%;
  max-width: 700px;
  image-rendering: pixelated;
  pointer-events: none;
}

.btn-reiniciar {
  position: absolute;
  bottom: 38.8%;
  font-family: "Press Start 2P", monospace;
  font-size: 16px;
  background: red;
  color: #fff;
  padding: 16px 32px;
  border: 4px solid black;
  box-shadow: 4px 4px black;
  cursor: pointer;
  transition: transform 0.1s;
  z-index: 1000;
}

.btn-reiniciar:hover {
  transform: scale(1.05);
  background: rgb(100, 0, 0);
}

.pause-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.9);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 9998;
}

.img-pause {
  max-width: 700px;
  image-rendering: pixelated;
  pointer-events: none;
}

.btn-continuar {
  margin-top: 100px;
  font-family: "Press Start 2P", monospace;
  font-size: 16px;
  background: limegreen;
  color: white;
  padding: 16px 32px;
  border: 4px solid black;
  box-shadow: 4px 4px black;
  cursor: pointer;
  transition: transform 0.1s;
  z-index: 1000;
}

.btn-continuar:hover {
  transform: scale(1.05);
  background: green;
}

.moeda-girando {
  position: absolute;
  top: 30px;
  left: 50%;
  transform: translateX(-50%);
  width: 180px;
  height: auto;
  image-rendering: pixelated;
  z-index: 10;
}

.moeda-girando-dourada {
  width: 190px;
  height: auto;
  position: absolute;
  left: 30%;
  bottom: 600px;
  z-index: 10;
}

.pergunta-overlay {
  position: fixed;
  inset: 0;
  background-color: rgba(0, 0, 0, 0.85);
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  z-index: 9998;
}

.img-pergunta {
  width: 500px;
  image-rendering: pixelated;
  pointer-events: none;
}

.contador {
  font-family: "Press Start 2P", monospace;
  font-size: 28px;
  color: #00ff88;
  margin-top: 30px;
}

.intro-hq {
  position: fixed;
  inset: 0;
  background-color: black;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  z-index: 9999;
}

.hq-img {
  max-width: 100%;
  max-height: 100vh;
  image-rendering: pixelated;
}

.btn-skip {
  margin-top: 20px;
  font-family: "Press Start 2P", monospace;
  font-size: 14px;
  padding: 12px 24px;
  background: red;
  color: white;
  border: 4px solid black;
  box-shadow: 4px 4px black;
  cursor: pointer;
}

/* Estilos para o tiro de laser */
.tiro {
  position: absolute;
  width: 180px;
  height: auto;
  image-rendering: pixelated;
  z-index: 2;
  pointer-events: none;
}

/* Barra de vida do boss */
.barra-vida {
  position: absolute;
  top: 10px;
  right: 10px;
  width: 200px;
  height: 20px;
  background-color: #444;
  border: 2px solid #222;
  border-radius: 4px;
  overflow: hidden;
  z-index: 10;
}

.barra-vida-fill {
  height: 100%;
  background-color: #e74c3c;
  transition: width 0.2s ease;
}
</style>