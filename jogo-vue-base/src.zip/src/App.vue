<template>
  <FaseManager />
</template>

<script setup>
import FaseManager from './components/FaseManager.vue'
</script>

